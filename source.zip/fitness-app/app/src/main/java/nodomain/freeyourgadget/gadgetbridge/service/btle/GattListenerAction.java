package nodomain.freeyourgadget.gadgetbridge.service.btle;

public interface GattListenerAction {
    GattCallback getGattCallback();
}
