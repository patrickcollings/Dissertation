module.exports = {
	authCode: String,
	authCodeExpiresAt: Date,
	client: String,
	user: String
};