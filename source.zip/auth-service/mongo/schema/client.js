module.exports = {
	clientId: String,
	clientSecret: String,
	grants: [String],
	redirectUris: [String]
};
