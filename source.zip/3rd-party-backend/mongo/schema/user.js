module.exports = {
	username: String,
	password: String,
	userId: String
};
